﻿博客地址：http://www.cnblogs.com/menglingqian/p/7392245.html 
http://www.cnblogs.com/menglingqian/p/7392425.html

代码：python manage.py runserver 8000
